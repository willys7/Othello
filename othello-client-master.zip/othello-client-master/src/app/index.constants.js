(function() {
  'use strict';

  angular
    .module('othelloClient');

})();
